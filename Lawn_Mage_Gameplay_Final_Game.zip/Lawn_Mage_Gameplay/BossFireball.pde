// BossFireball — red version of the player fireball, bigger, fixed speed 8.5
// Only fired during the boss shield phase

class BossFireball
{
  float xPos, yPos;
  float vx;
  boolean active = false;
  float CORE_SIZE = 54;   // bigger than player's 40px core

  BossFireball() {}

  void FireShield(float x, float y)
  {
    if (active) return;
    xPos   = x;
    yPos   = y;
    vx     = -8.5;  // crossbow troll speed, travels left
    active = true;
  }

  void Deactivate() { active = false; }

  void Move()
  {
    if (!active) return;
    xPos += vx;
    if (xPos < 0) Deactivate();  // passes through wall, deactivates at left edge
  }

  void Render()
  {
    if (!active) return;
    // Mirror player fireball style: outer circle + inner white — but red
    fill(220, 20, 0, 255);
    circle(xPos, yPos, CORE_SIZE);
    fill(255, 160, 160, 255);
    circle(xPos, yPos, CORE_SIZE * 0.45);
  }

  boolean CheckHit(float px, float py, float radius)
  {
    if (!active) return false;
    return dist(xPos, yPos, px, py) < (CORE_SIZE / 2 + radius);
  }
}

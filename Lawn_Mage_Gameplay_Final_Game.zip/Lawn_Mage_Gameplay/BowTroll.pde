// Bow Troll — fast mover, slow arrow, shoots randomly
// HP: 3, Speed: 1.1, Arrow speed: 3.5
// Shoots every 180–360 frames (random interval)

class BowTroll
{
  float xPos, yPos;
  int   hitFlashTimer = 0;
  float speed  = 0.94;
  int   hp, maxHp;
  PImage sprite;
  float sw = 138, sh = 138;

  float[] lanes = { 182, 294, 405, 519, 632 };

  Arrow  arrow;
  int    shootCooldown;
  int    shootTimer = 0;

  BowTroll(float x, float y)
  {
    maxHp  = 3;
    hp     = maxHp;
    xPos   = x;
    yPos   = y;
    sprite = sprBowTroll;
    arrow  = new Arrow(5.5);
    ResetShootTimer();
  }

  void ResetShootTimer()
  {
    // Closer to wall (xPos~231) = shoots less.  Farther right (xPos~800) = shoots more.
    // Clamp to visible range so off-screen spawns get a mid cooldown, not the shortest
    float usableX = constrain(xPos, 231, 800);
    float t = (usableX - 231) / (800.0 - 231.0);  // 0=at wall, 1=far right
    int lo = (int)lerp(240, 80, t);
    int hi = lo + 80;
    shootCooldown = (int)random(lo, hi);
    shootTimer    = 0;
  }

  void RenderBody()
  {
    if (hp <= 0) { speed = 0; return; }
    imageMode(CENTER);
    hint(ENABLE_STROKE_PURE);
    image(sprite, xPos, yPos - 5, sw, sh);
    noTint();
    imageMode(CORNER);
  }

  void DrawHealthBar()
  {
    if (hp <= 0) { speed = 0; return; }
    float barW = 44, barH = 5;
    float bx = xPos - barW/2, by = yPos - sh/2 - 10;
    noStroke(); fill(40, 10, 10); rect(bx, by, barW, barH, 2);
    float ratio = (float)hp / maxHp;
    fill(lerpColor(color(220, 40, 40), color(80, 220, 60), ratio));
    rect(bx, by, barW * ratio, barH, 2);
    noFill(); stroke(255, 255, 255, 160); strokeWeight(1);
    rect(bx, by, barW, barH, 2); noStroke();
  }

  void Move()
  {
    if (hp <= 0) { speed = 0; return; }
    if (hitFlashTimer > 0) hitFlashTimer--;
    xPos -= speed;

    // Shoot logic — fires when timer hits cooldown
    // Only count down and shoot once fully on screen
    if (xPos <= width - sw/2) {
      shootTimer++;
      if (shootTimer >= shootCooldown)
      {
        arrow.Fire(xPos - sw/2, yPos);
        PlayRandom(sfxShootingArrow);
        ResetShootTimer();
      }
    }


    if (hp > 0 && xPos < 231) { wl.TakeDamage(1); Respawn(); }
  }

  void RenderArrow() { arrow.Render(); }

  void Respawn()
  {
    hp   = maxHp;
    xPos = width + random(100, 500);
    yPos = lanes[int(random(lanes.length))];
    arrow.Deactivate();
    ResetShootTimer();
  }

  boolean CheckHit(float fx, float fy)
  {
    if (hp <= 0) return false;
    return dist(fx, fy, xPos, yPos) < sw * 0.55;
  }

  boolean Hit() { hp--; return hp <= 0; }
}

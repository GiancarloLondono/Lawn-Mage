// ── SoundManager — loads all SFX and plays random variants ──────
// Naming convention: Category_1.wav / Category_2.wav (or single file)

SoundFile[] sfxFireball;
SoundFile[] sfxGoblin;
SoundFile[] sfxOrc;
SoundFile[] sfxOgre;
SoundFile[] sfxBowTroll;
SoundFile[] sfxCrossBowTroll;
SoundFile[] sfxShootingArrow;
SoundFile[] sfxGettingHurt;
SoundFile[] sfxBoss;
SoundFile   sfxGameOver;
SoundFile   sfxWallHit;
void LoadSounds()
{
  sfxFireball       = new SoundFile[]{ new SoundFile(this, "Fire_Ball_1.wav"),
                                       new SoundFile(this, "Fire_Ball_2.wav") };
  sfxGoblin         = new SoundFile[]{ new SoundFile(this, "Goblin_1.wav"),
                                       new SoundFile(this, "Goblin_2.wav") };
  sfxOrc            = new SoundFile[]{ new SoundFile(this, "Orc_1.wav"),
                                       new SoundFile(this, "Orc_2.wav") };
  sfxOgre           = new SoundFile[]{ new SoundFile(this, "Ogre_1.wav"),
                                       new SoundFile(this, "Ogre_2.wav") };
  sfxBowTroll       = new SoundFile[]{ new SoundFile(this, "Bow_Troll_1.wav"),
                                       new SoundFile(this, "Bow_Troll_2.wav") };
  sfxCrossBowTroll  = new SoundFile[]{ new SoundFile(this, "Cross_Bow_Troll_1.wav"),
                                       new SoundFile(this, "Cross_Bow_Troll_2.wav") };
  sfxShootingArrow  = new SoundFile[]{ new SoundFile(this, "Shooting_Arrow_1.wav"),
                                       new SoundFile(this, "Shooting_Arrow_2.wav") };
  sfxGettingHurt    = new SoundFile[]{ new SoundFile(this, "Getting_Hurt_1.wav"),
                                       new SoundFile(this, "Getting_Hurt_2.wav") };
  sfxBoss           = new SoundFile[]{ new SoundFile(this, "Boss_1.wav"),
                                       new SoundFile(this, "Boss_2.wav"),
                                       new SoundFile(this, "Boss_3.wav") };
  sfxGameOver       = new SoundFile(this, "Game_Over.wav");
  sfxWallHit        = new SoundFile(this, "Click_Button.wav");
}

void PlayRandom(SoundFile[] variants)
{
  SoundFile s = variants[(int)random(variants.length)];
  if (s.isPlaying()) s.stop();
  s.play();
}

void PlayOnce(SoundFile s)
{
  if (s.isPlaying()) s.stop();
  s.play();
}

void SetAllSFXAmp(float amp)
{
  for (SoundFile s : sfxFireball)      s.amp(amp * 1.8);  // fireball louder
  for (SoundFile s : sfxGoblin)        s.amp(amp);
  for (SoundFile s : sfxOrc)           s.amp(amp);
  for (SoundFile s : sfxOgre)          s.amp(amp);
  for (SoundFile s : sfxBowTroll)      s.amp(amp);
  for (SoundFile s : sfxCrossBowTroll) s.amp(amp);
  for (SoundFile s : sfxShootingArrow) s.amp(amp);
  for (SoundFile s : sfxGettingHurt)   s.amp(amp);
  for (SoundFile s : sfxBoss) s.amp(amp);
  sfxGameOver.amp(amp);
  sfxWallHit.amp(amp * 0.7);
}

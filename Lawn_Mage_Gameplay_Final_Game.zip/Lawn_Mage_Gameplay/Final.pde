import processing.sound.*;

SoundFile menuMusic;
SoundFile gameMusic;
boolean   playingMenu = true;

MainMenu   menu;
Game       game;
EndCredits credits;

void setup() 
{
  size(800, 800, P2D);
  smooth(8);

  menuMusic = new SoundFile(this, "menu_music.mp3");
  gameMusic = new SoundFile(this, "game_music.mp3");
  menuMusic.amp(0.02);
  gameMusic.amp(0.02);
  menuMusic.loop();
  gameMusic.amp(0.02);  // pre-buffer game music
  playingMenu = true;


  // Preload all sprites once — prevents loadImage() lag on each wave start
  sprGoblin        = loadImage("goblin.png");
  sprOrc           = loadImage("orc.png");
  sprOgre          = loadImage("ogre.png");
  sprBowTroll      = loadImage("bow_troll.png");
  sprCrossBowTroll = loadImage("crossbow_troll.png");
  sprBoss          = loadImage("boss.png");
  sprPlayer        = loadImage("player.png");
  sprPlayerDead    = loadImage("player_dead.png");
  sprArrow         = loadImage("arrow.png");

  LoadSounds();
  SetAllSFXAmp(1.5);
  menu    = new MainMenu();
  game    = new Game();
  credits = new EndCredits();
}

void draw() 
{
  if (credits.isActive) {
    // Credits scene — stop game music, play menu music softly
    if (!playingMenu) {
      gameMusic.stop();
      menuMusic.loop();
      playingMenu = true;
    }
    credits.HandleCredits();
    return;
  }

  // Switch tracks when active scene changes
  if (!menu.isActive && playingMenu) {
    menuMusic.stop();
    gameMusic.loop();
    playingMenu = false;
  } else if (menu.isActive && !playingMenu) {
    gameMusic.stop();
    menuMusic.loop();
    playingMenu = true;
  }

  if (menu.isActive) menu.HandleMenu();
  else               game.HandleGame();
}

void mouseReleased() 
{
  if (credits.isActive) { credits.OnMouseReleased(); return; }
  if (menu.isActive)    { menu.OnMouseReleased(); return; }
  game.OnMouseReleased();
}

void keyPressed()  { player.OnKeyPressed();  }
void keyReleased() { player.OnKeyReleased(); }

// Crossbow Troll — slow mover, fast arrow, shoots randomly
// HP: 5, Speed: 0.55, Arrow speed: 9
// Shoots every 240–480 frames (random interval)

class CrossbowTroll
{
  float xPos, yPos;
  int   hitFlashTimer = 0;
  float speed  = 0.75;
  int   hp, maxHp;
  PImage sprite;
  float sw = 148, sh = 148;

  float[] lanes = { 182, 294, 405, 519, 632 };

  Arrow  arrow;
  int    shootCooldown;
  int    shootTimer = 0;

  CrossbowTroll(float x, float y)
  {
    maxHp  = 5;
    hp     = maxHp;
    xPos   = x;
    yPos   = y;
    sprite = sprCrossBowTroll;
    arrow  = new Arrow(8.5);
    ResetShootTimer();
  }

  void ResetShootTimer()
  {
    float usableX = constrain(xPos, 231, 800);
    float t = (usableX - 231) / (800.0 - 231.0);
    int lo = (int)lerp(200, 60, t);
    int hi = lo + 60;
    shootCooldown = (int)random(lo, hi);
    shootTimer    = 0;
  }

  void RenderBody()
  {
    if (hp <= 0) { speed = 0; return; }
    imageMode(CENTER);
    hint(ENABLE_STROKE_PURE);
    image(sprite, xPos, yPos - 8, sw, sh);
    noTint();
    imageMode(CORNER);
  }

  void DrawHealthBar()
  {
    if (hp <= 0) { speed = 0; return; }
    float barW = 50, barH = 5;
    float bx = xPos - barW/2, by = yPos - sh/2 - 10;
    noStroke(); fill(40, 10, 10); rect(bx, by, barW, barH, 2);
    float ratio = (float)hp / maxHp;
    fill(lerpColor(color(220, 40, 40), color(80, 220, 60), ratio));
    rect(bx, by, barW * ratio, barH, 2);
    noFill(); stroke(255, 255, 255, 160); strokeWeight(1);
    rect(bx, by, barW, barH, 2); noStroke();
  }

  void Move()
  {
    if (hp <= 0) { speed = 0; return; }
    if (hitFlashTimer > 0) hitFlashTimer--;
    xPos -= speed;

    if (xPos <= width - sw/2) {
      shootTimer++;
      if (shootTimer >= shootCooldown)
      {
        arrow.Fire(xPos - sw/2, yPos);
        PlayRandom(sfxShootingArrow);
        ResetShootTimer();
      }
    }


    if (hp > 0 && xPos < 231) { wl.TakeDamage(1); Respawn(); }
  }

  void RenderArrow() { arrow.Render(); }

  void Respawn()
  {
    hp   = maxHp;
    xPos = width + random(100, 500);
    yPos = lanes[int(random(lanes.length))];
    arrow.Deactivate();
    ResetShootTimer();
  }

  boolean CheckHit(float fx, float fy)
  {
    if (hp <= 0) return false;
    return dist(fx, fy, xPos, yPos) < sw * 0.55;
  }

  boolean Hit() { hp--; return hp <= 0; }\
}

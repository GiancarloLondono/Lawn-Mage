// ── End Credits ─────────────────────────────────────────────────────────────
// Left half: scrolling credits text on dark wood panel
// Right half: end credits illustration (never flipped/distorted)

class EndCredits
{
  boolean isActive = false;
  PImage  creditsImg;
  Button  menuButton;

  float scrollY    = 0;
  float SCROLL_SPD = 1.1;

  // Total height of one full credits pass (so loop resets cleanly)
  float CONTENT_H  = 780;

  EndCredits()
  {
    creditsImg = loadImage("end_credits.jpg");

    menuButton             = new Button(24, 14, 190, 46, color(90, 40, 10));
    menuButton.name        = "Main Menu";
    menuButton.textColor   = color(255, 220, 80);
    menuButton.hoverColor  = color(160, 80, 20);
    menuButton.normalColor = color(90, 40, 10);
    menuButton.textSize    = 16;
  }

  void HandleCredits()
  {
    background(22, 10, 4);

    int panelW = (int)(width * 0.38);  // narrower left panel
    int imgX   = panelW;               // image gets 62% of canvas

    // ── Right half: image — drawn first, no transform ────────────────────
    // Fit image into right half preserving aspect ratio (crop to fill)
    imageMode(CORNER);
    float iw = creditsImg.width;
    float ih = creditsImg.height;
    float targetW = width - imgX;
    float targetH = height;
    float scaleX = targetW / iw;
    float scaleY = targetH / ih;
    float sc     = min(scaleX, scaleY) * 1.08;   // slight overscan to reduce bars
    float drawW  = iw * sc;
    float drawH  = ih * sc;
    float offX   = imgX + (targetW - drawW) / 2; // center crop horizontally
    float offY   = (targetH - drawH) / 2;        // center crop vertically
    image(creditsImg, offX, offY, drawW, drawH);

    // ── Left half: dark wood panel over anything that bled left ──────────
    fill(32, 12, 3); noStroke();
    rect(0, 0, panelW, height);

    // Subtle inner border glow
    noFill();
    stroke(200, 160, 50, 55); strokeWeight(1);
    rect(12, 12, panelW - 24, height - 24, 6);
    noStroke();

    // Gold divider line on right edge of panel
    stroke(200, 160, 50, 180); strokeWeight(2);
    line(panelW, 0, panelW, height);
    noStroke();

    // ── Clipping mask: only draw text inside left panel ───────────────────
    // (Processing doesn't clip; we just keep cx inside panelW)
    float cx = panelW / 2.0;

    // ── Scroll upward, loop seamlessly ────────────────────────────────────
    scrollY -= SCROLL_SPD;
    if (scrollY < -(CONTENT_H + 40)) scrollY = 0;

    // startY begins below bottom of screen, scrolls up
    float y = height + scrollY;

    textAlign(CENTER, CENTER);

    // ── TITLE ─────────────────────────────────────────────────────────────
    y += 30;
    textSize(42);
    fill(0, 0, 0, 210); text("LAWN MAGE", cx + 2, y + 2);
    fill(255, 220, 80);  text("LAWN MAGE", cx,     y);

    y += 44;
    textSize(16);
    fill(180, 140, 70);
    text("A Tower Defense Game", cx, y);

    y += 28;
    DrawDivider(cx, y, 170);

    // ── LEAD CREDIT ───────────────────────────────────────────────────────
    y += 32;
    Label(cx, y, "DESIGNER, ARTIST & PROGRAMMER");
    y += 22;
    Name(cx, y, "Giancarlo Londono");

    y += 40;
    DrawDivider(cx, y, 130);

    // ── SPECIAL THANKS ────────────────────────────────────────────────────
    y += 32;
    textSize(24);
    fill(0, 0, 0, 190); text("Special Thanks", cx + 2, y + 2);
    fill(255, 220, 80);  text("Special Thanks", cx,     y);

    y += 38;
    Label(cx, y, "Professor");
    y += 22;
    Name(cx, y, "Amir Ahmadi");

    y += 42;
    Label(cx, y, "Student");
    y += 22;
    Name(cx, y, "Collin Grayson");

    y += 42;
    Label(cx, y, "Student");
    y += 22;
    Name(cx, y, "Aidan Vanhoozer");

    y += 40;
    DrawDivider(cx, y, 130);

    // ── MUSIC ─────────────────────────────────────────────────────────────
    y += 32;
    Label(cx, y, "MUSIC");
    y += 22;
    Name(cx, y, "Fayluna");
    y += 26;
    textSize(16); fill(180, 140, 80);
    text("(Francesca Londono)", cx, y);

    y += 40;
    DrawDivider(cx, y, 110);

    // ── CLOSING ───────────────────────────────────────────────────────────
    y += 34;
    textSize(22); fill(160, 120, 55);
    text("Thank you for playing!", cx, y);
    y += 26;
    textSize(14); fill(110, 85, 40);
    text("\u00A9 2025 Giancarlo Londono", cx, y);

    // ── MAIN MENU BUTTON — pinned bottom-left ────────────────────────────
    menuButton.xPos = 24;
    menuButton.yPos = 14;
    menuButton.Hover();
    menuButton.Render();
  }

  // Small all-caps role/section label in gold
  void Label(float cx, float y, String s)
  {
    textAlign(CENTER, CENTER);
    textSize(13);
    fill(200, 160, 50);
    text(s, cx, y);
  }

  // Larger cream name with drop shadow
  void Name(float cx, float y, String s)
  {
    textAlign(CENTER, CENTER);
    textSize(22);
    fill(0, 0, 0, 170); text(s, cx + 1, y + 1);
    fill(230, 210, 155); text(s, cx,     y);
  }

  void DrawDivider(float cx, float y, float len)
  {
    stroke(200, 160, 50, 90); strokeWeight(1);
    line(cx - len / 2, y, cx + len / 2, y);
    noStroke();
  }

  void OnMouseReleased()
  {
    if (!isActive) return;
    if (menuButton.Onclick()) {
      menuButton.isHovered = false;
      isActive  = false;
      scrollY   = 0;
      menu.isActive = true;
    }
  }
}

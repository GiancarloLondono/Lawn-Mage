// Assets — global sprites loaded once in setup() to eliminate wave-start lag

PImage sprGoblin;
PImage sprOrc;
PImage sprOgre;
PImage sprBowTroll;
PImage sprCrossBowTroll;
PImage sprBoss;
PImage sprPlayer;
PImage sprPlayerDead;
PImage sprArrow;

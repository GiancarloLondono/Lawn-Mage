class Goblin 
{
  float xPos, yPos;
  int   hitFlashTimer = 0;
  float speed = 1.32;
  int hp, maxHp;
  PImage sprite;
  float sw = 88, sh = 88;  // small

  float[] lanes = { 182, 294, 405, 519, 632 };

  Goblin(float x, float y) 
  {
    maxHp  = 2;
    hp     = maxHp;
    xPos   = x;
    yPos   = y;
    sprite = sprGoblin;
  }

  void RenderBody() 
  {
    if (hp <= 0) { speed = 0; return; }
    imageMode(CENTER);
    if (hitFlashTimer > 0) tint(255, 60, 60); else noTint();
    image(sprite, xPos, yPos + 14, sw, sh);
    noTint();
    imageMode(CORNER);
  }

  void DrawHealthBar() 
  {
    if (hp <= 0) { speed = 0; return; }
    float barW = 38, barH = 5;
    float bx = xPos - barW/2, by = yPos - sh/2 - 10;
    noStroke(); fill(40,10,10); rect(bx, by, barW, barH, 2);
    float ratio = (float)hp / maxHp;
    fill(lerpColor(color(220,40,40), color(80,220,60), ratio));
    rect(bx, by, barW*ratio, barH, 2);
    noFill(); stroke(255,255,255,160); strokeWeight(1);
    rect(bx, by, barW, barH, 2); noStroke();
  }

  void Move() 
  {
    if (hp <= 0) { speed = 0; return; }
    if (hitFlashTimer > 0) hitFlashTimer--;
    xPos -= speed;
    if (hp > 0 && xPos < 231) { wl.TakeDamage(1); Respawn(); }
  }

  void Respawn() 
  {
    hp   = maxHp;
    xPos = width + random(50, 400);
    yPos = lanes[int(random(lanes.length))];
  }

  boolean CheckHit(float fx, float fy) 
  {
    if (hp <= 0) return false;
    return dist(fx, fy, xPos, yPos) < sw * 0.6;
  }

  boolean Hit() { hp--; return hp <= 0; }
}

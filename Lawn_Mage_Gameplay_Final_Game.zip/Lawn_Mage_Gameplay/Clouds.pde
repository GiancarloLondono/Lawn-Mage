class Cloud 
{
  float xPos, yPos;
  float speed;

  // Cloud extents relative to yPos:
  //   Lowest puff bottom:  yPos - 115 + 32 = yPos - 83   (below yPos)
  //   Highest puff top:    yPos - 155 - 32 = yPos - 187  (above yPos)
  // Fully off bottom: yPos - 83 > height  →  yPos > height + 83
  // Fully off top:    yPos - 187 < 0      →  yPos < 187
  // Re-enter from top fully hidden:  yPos = -220  (top of cloud at -220-187 = off screen)
  // Re-enter from bottom fully hidden: yPos = height + 90

  Cloud(float x, float y, float fixedSpeed) 
  {
    xPos  = x;
    yPos  = y;
    speed = fixedSpeed;
  }

  void Render() 
  {
    noStroke();
    fill(255, 255, 255);
    ellipse(xPos - 45, yPos - 115, 110, 65);
    ellipse(xPos +  0, yPos - 155, 110, 65);
    ellipse(xPos + 45, yPos - 115, 110, 65);
  }

  void Move() 
  {
    yPos += speed;

    // Moving down — fully off bottom, reappear fully off top
    if (speed > 0 && yPos > height + 300)
    {
      yPos = -300;
      xPos = random(280, 730);
    }

    // Moving up — fully off top, reappear fully off bottom
    if (speed < 0 && yPos < -300)
    {
      yPos = height + 300;
      xPos = random(280, 730);
    }
  }
}

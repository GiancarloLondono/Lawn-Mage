Fireball fireBall;

class Player
{
  float xPos, yPos;
  float speed = 9;
  boolean up, down;
  PImage sprite;
  PImage deadSprite;

  float spriteW = 160;
  float spriteH = 160;

  int maxHp = 3;
  int hp    = 3;

  // Black flash on hit
  int   hitFlashTimer = 0;
  int   HIT_FLASH_DUR = 36;  // 0.6s

  // Death & respawn
  boolean dead         = false;
  int     respawnTimer = 0;
  int     RESPAWN_FRAMES = 180; // 3 seconds

  // Track death position for X marker
  float deathX = -999;
  float deathY = -999;

  Player(float x, float y)
  {
    xPos     = x;
    yPos     = y;
    sprite = sprPlayer;
    deadSprite = sprPlayerDead;
    fireBall = new Fireball(xPos, yPos);
  }

  void TakeDamage()
  {
    if (dead) return;
    hp--;
    hitFlashTimer = HIT_FLASH_DUR;
    // Always play hurt sound immediately on hit
    for (SoundFile s : sfxGettingHurt) s.stop();
    sfxGettingHurt[(int)random(sfxGettingHurt.length)].play();
    if (hp <= 0) {
      hp       = 0;
      dead     = true;
      deathX   = xPos;
      deathY   = yPos;
      respawnTimer = 0;
      fireBall.Deactivate();
    }
  }

  // True only when hp=0 AND dead AND no more respawns possible (permanent game over)
  boolean isDead()     { return hp <= 0 && dead; }

  // Called every frame
  void Update()
  {
    if (dead && hp <= 0) {
      respawnTimer++;
      if (respawnTimer >= RESPAWN_FRAMES) {
        dead         = false;
        hp           = maxHp;
        hitFlashTimer = 0;
        deathX       = -999;
        deathY       = -999;
      }
    }
  }

  void Render()
  {
    Update();

    // Show dead sprite at death position while respawning
    if (dead) {
      if (deathX > 0) {
        imageMode(CENTER);
        hint(ENABLE_STROKE_PURE);
        image(deadSprite, deathX, deathY, spriteW, spriteH);
        imageMode(CORNER);
      }
      return;
    }

    // Black flash: solid black for first 12 frames, then strobe
    noTint();
    if (hitFlashTimer > 0) {
      hitFlashTimer--;
      if (hitFlashTimer > HIT_FLASH_DUR - 12 || (hitFlashTimer / 4) % 2 == 0) {
        tint(0, 0, 0);
      }
    }

    imageMode(CENTER);
    hint(ENABLE_STROKE_PURE);
    image(sprite, xPos, yPos, spriteW, spriteH);
    imageMode(CORNER);
    noTint();

    fireBall.UpdateYPos();
    DrawHealthBar();
  }

  void DrawHealthBar()
  {
    float startX = 520, ty = 32;
    float r = 20;
    float gap = 10;
    noStroke();
    for (int i = 0; i < maxHp; i++) {
      float cx = startX + i * (r * 2 + gap);
      fill(20, 10, 10);
      ellipse(cx, ty, (r + 3) * 2, (r + 3) * 2);
      fill(i < hp ? color(215, 50, 60) : color(60, 30, 30));
      ellipse(cx, ty, r * 2, r * 2);
    }
  }

  void Move()
  {
    if (dead) return;
    if (yPos - 45 <= 125)          up   = false;
    if (yPos + spriteH/2 >= 695)   down = false;
    if (up)   yPos -= speed;
    if (down) yPos += speed;
    if (xPos + spriteW/2 > 186)    xPos = 186 - spriteW/2;
  }

  void OnKeyPressed()
  {
    if (dead) return;
    if (key == 'w' || key == 'W') up = true;
    if (key == 's' || key == 'S') down = true;
    if (key == ' ') fireBall.Fire();
  }

  void OnKeyReleased()
  {
    if (key == 'w' || key == 'W') up   = false;
    if (key == 's' || key == 'S') down = false;
  }

  void AttackReset() {}
}

class Button 
{
  float xPos, yPos;
  float Width, Height;
  float textSize = 50;
  color buttonColor;
  color hoverColor;
  color normalColor;
  color textColor = color(93, 185, 75);

  boolean isHovered = false;

  String name = "Button";

  Button(float x, float y, float w, float h, color c) 
  {
    xPos = x;
    yPos = y;
    Width = w;
    Height = h;

    normalColor = buttonColor = c;
    hoverColor =color(237, 231, 54);
  }

  void Render() 
  {
    // Drop shadow
    fill(0, 0, 0, 100);
    noStroke();
    rect(xPos + 4, yPos + 4, Width, Height, 10);

    // Button body
    fill(buttonColor);
    stroke(200, 160, 50);
    strokeWeight(2);
    rect(xPos, yPos, Width, Height, 10);

    // Button text
    noStroke();
    fill(textColor);
    textSize(textSize);
    textAlign(CENTER, CENTER);
    text(name, xPos + Width/2, yPos + Height/2);
  }


  void Hover() 
  {
    buttonColor = normalColor;
    isHovered = false;
    if (mouseX > xPos && mouseX < xPos + Width)
      if (mouseY > yPos && mouseY < yPos + Height)
      {
        buttonColor = hoverColor;
        isHovered = true;
      }
  }

  boolean Onclick() 
  {
    if (isHovered == true)
    {
      println(name + "is clicked");
      return true;
    }

    return false;
  }
}

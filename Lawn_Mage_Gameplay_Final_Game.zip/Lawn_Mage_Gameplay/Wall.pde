class Wall
{
  int maxHP = 6;
  int hp    = 6;
  boolean broken = false;
  int healFlashTimer = 0;  // shows + sign when healed

  int[]     laneYs  = { 125, 239, 353, 467, 581 };
  boolean[] isLight = { true, false, true, false, true };

  int[][] grassX = {
    { 320, 570 },
    { 410, 630, 760 },
    { 280, 510 },
    { 350, 590, 730 },
    { 300, 540 }
  };

  Wall() { }

  void TakeDamage(int amount)
  {
    hp -= amount;
    if (hp <= 0) { hp = 0; if (!broken) { broken = true; PlayOnce(sfxGameOver); } }
    else { PlayOnce(sfxWallHit); }
  }

  void RenderLanes()
  {
    noStroke();
    for (int i = 0; i < 5; i++)
    {
      int y = laneYs[i];
      if (isLight[i]) fill(198, 225, 116);
      else            fill(167, 225, 66);
      rect(231, y, 570, 114);

      color blade, shadow;
      if (isLight[i]) { blade = color(140, 200, 50);  shadow = color(110, 165, 35); }
      else            { blade = color(210, 235, 130); shadow = color(175, 205, 90); }

      for (int g = 0; g < grassX[i].length; g++)
      {
        float gx = grassX[i][g];
        float gy = y + 102;
        fill(shadow); triangle(gx-9, gy, gx+9, gy, gx,    gy-7);
        fill(blade);  triangle(gx-6, gy, gx-1, gy, gx-10, gy-20);
        fill(blade);  triangle(gx+1, gy, gx+6, gy, gx+10, gy-18);
        fill(blade);  triangle(gx-3, gy, gx+3, gy, gx,    gy-26);
      }
    }
  }

  // Draw wood + grey tower caps BEHIND forest
  void RenderBack()
  {
    noStroke();
    // Brown wood — lane area only
    fill(187, 114, 43);
    rect(0, 125, 186, 570);
    // Horizontal plank lines across the wood
    stroke(152, 88, 28); strokeWeight(2);
    int[] plankYs = {175, 225, 275, 325, 375, 425, 475, 525, 575, 625, 670};
    for (int py : plankYs) line(2, py, 184, py);
    // Vertical nail/joint marks at plank edges
    stroke(140, 78, 22); strokeWeight(3);
    int[] nailXs = {55, 130};
    for (int nx2 : nailXs)
      for (int py : plankYs)
        point(nx2, py);
    noStroke();
    // Top tower cap
    fill(148, 146, 144); rect(0, 0, 231, 125);
    fill(195, 193, 191); rect(0, 0, 231, 7);
    fill(115, 113, 111); rect(0, 118, 231, 7);
    fill(130, 128, 126); rect(223, 0, 8, 125);
    // Bottom tower cap
    fill(148, 146, 144); rect(0, 695, 231, 105);
    fill(195, 193, 191); rect(0, 695, 231, 7);
    fill(115, 113, 111); rect(0, 793, 231, 7);
    fill(130, 128, 126); rect(223, 695, 8, 105);
  }

  // Draw stone face + platforms + cracks OVER forest (but forest trees still overlap caps)
  void Render()
  {
    noStroke();
    // Stone face — full height
    fill(174, 172, 170);
    rect(186, 0, 45, 800);
    // Platform 1
    fill(148, 146, 144); rect(231, 220, 58, 38);
    fill(195, 193, 191); rect(231, 220, 58, 6);
    fill(100, 98, 96);   rect(231, 252, 58, 6);
    fill(115, 113, 111); rect(283, 220, 6, 38);
    // Platform 2
    fill(148, 146, 144); rect(231, 558, 58, 38);
    fill(195, 193, 191); rect(231, 558, 58, 6);
    fill(100, 98, 96);   rect(231, 590, 58, 6);
    fill(115, 113, 111); rect(283, 558, 6, 38);
    // Cracks — more appear every 2 HP lost (hp<=4, hp<=2, hp<=1)
    if (hp <= 4) {
      stroke(60, 30, 10, 130); strokeWeight(1.5);
      line(200, 130, 218, 240);
      line(190, 350, 210, 480);
      noStroke();
    }
    if (hp <= 2) {
      stroke(50, 25, 8, 170); strokeWeight(2);
      line(186, 130, 210, 280);
      line(200, 240, 182, 430);
      line(214, 390, 196, 570);
      line(188, 500, 220, 690);
      noStroke();
    }
    if (hp <= 1) {
      stroke(40, 15, 5, 200); strokeWeight(2.5);
      line(195, 200, 225, 320);
      line(185, 310, 215, 200);
      line(220, 450, 188, 600);
      line(192, 560, 228, 430);
      line(205, 640, 185, 750);
      noStroke();
    }

    // ── Lemonade props ────────────────────────────────────
    // Two crates top-left of brown wood
    DrawCrate(28,  152, 26);
    DrawCrate(64,  158, 18);
    // Pitcher bottom-right of brown wood
    DrawPitcher(155, 676);
    // Pitcher + cup on stone face
    DrawPitcher(204, 340);
    DrawCup(213, 480);
  }

  void DrawPitcher(float x, float y)
  {
    // Outline
    fill(30, 15, 5); noStroke();
    rect(x - 14, y - 22, 28, 38, 5);
    // Yellow body
    fill(255, 225, 50);
    rect(x - 11, y - 19, 22, 32, 3);
    // Handle
    noFill(); stroke(30, 15, 5); strokeWeight(4);
    arc(x + 13, y - 5, 16, 20, -HALF_PI, HALF_PI);
    noStroke();
    // Rim
    fill(30, 15, 5);
    rect(x - 15, y - 26, 30, 6, 3);
    // Straw
    fill(220, 60, 60);
    rect(x + 3, y - 46, 5, 24, 2);
  }

  void DrawCrate(float x, float y, float s)
  {
    noStroke();
    float h = s, v = s;
    // Outline
    fill(70, 38, 8);
    rect(x - h - 2, y - v - 2, h*2 + 4, v*2 + 4, 3);
    // Fill
    fill(170, 105, 40);
    rect(x - h, y - v, h*2, v*2, 2);
    // Plank lines
    stroke(130, 78, 25); strokeWeight(1.5);
    line(x, y - v, x, y + v);
    line(x - h, y, x + h, y);
    noStroke();
    // Lemon dot
    fill(255, 215, 35);
    ellipse(x, y, s * 0.65, s * 0.65);
  }

  void DrawCup(float x, float y)
  {
    noStroke();
    // Outline
    fill(30, 15, 5);
    quad(x - 10, y - 14, x + 10, y - 14, x + 8, y + 12, x - 8, y + 12);
    // White cup
    fill(238, 232, 215);
    quad(x - 8, y - 12, x + 8, y - 12, x + 6, y + 10, x - 6, y + 10);
    // Yellow lemonade fill (bottom 2/3)
    fill(255, 220, 45);
    quad(x - 7, y - 2, x + 7, y - 2, x + 6, y + 10, x - 6, y + 10);
    // Straw
    fill(220, 60, 60);
    rect(x + 2, y - 28, 4, 18, 1);
  }

  void LoadBarSprites() { }  // sprites no longer used for wall bar

  void TriggerHealFlash() { healFlashTimer = 90; }

  void DrawHealFlash()
  {
    if (healFlashTimer <= 0) return;
    healFlashTimer--;
    float alpha = min(255, healFlashTimer * 4);
    textAlign(CENTER, CENTER);
    textSize(28);
    fill(80, 255, 80, alpha);
    text("+1", 208, 72);
  }

  void DrawHealthBar()
  {
    float bx = 126, by = 6;
    float bw = 340, bh = 52;
    float gap = 4;
    float blockW = (bw - gap * (maxHP + 1)) / maxHP;

    // Glow effect when healed — healFlashTimer drives brightness
    float glowAmt = (healFlashTimer > 0) ? min(1.0, healFlashTimer / 45.0) : 0;

    noStroke();
    // Outer glow ring when healed
    if (glowAmt > 0) {
      float g = glowAmt * 255;
      fill(255, 210, 0, g * 0.5);
      rect(bx - 6, by - 6, bw + 12, bh + 12, 8);
    }

    // Dark container
    fill(25, 25, 25);
    rect(bx, by, bw, bh, 4);

    // Blocks
    for (int i = 0; i < maxHP; i++) {
      float bkx = bx + gap + i * (blockW + gap);
      float bky = by + gap;
      float bkh = bh - gap * 2;
      if (i < hp) {
        // Active block: tint green while healing, gold otherwise
        color c = lerpColor(color(255, 190, 0), color(255, 240, 80), glowAmt);
        fill(c);
      } else {
        fill(50, 40, 15);
      }
      rect(bkx, bky, blockW, bkh, 2);
    }
  }
}

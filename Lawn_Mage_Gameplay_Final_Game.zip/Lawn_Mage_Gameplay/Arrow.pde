// Arrow — sprite-based, mirrors Fireball system.
// Travels LEFT toward player. Passes through wall, only damages player.

class Arrow
{
  float xPos, yPos;
  float vx;
  float speed;
  boolean active;

  float currentAlpha;
  float renderedAlpha   = 255;
  float unrenderedAlpha = 0;

  PImage sprite;
  float  sw = 90, sh = 32;   // display size — wide, thin

  Arrow(float arrowSpeed)
  {
    speed        = arrowSpeed;
    currentAlpha = 0;
    active       = false;
    xPos         = -500;
    yPos         = -500;
    sprite = sprArrow;
  }

  void Fire(float startX, float startY)
  {
    if (!active)
    {
      xPos         = startX;
      yPos         = startY;
      vx           = -speed;
      currentAlpha = renderedAlpha;
      active       = true;
    }
  }

  void Render()
  {
    if (currentAlpha > 0)
    {
      tint(255, currentAlpha);
      imageMode(CENTER);
      hint(ENABLE_STROKE_PURE);
      image(sprite, xPos, yPos, sw, sh);
      imageMode(CORNER);
      noTint();
    }

    if (active)
    {
      xPos += vx;

      // Hit player (only if alive)
      if (!player.dead && dist(xPos, yPos, player.xPos, player.yPos) < 46)
      {
        player.TakeDamage();
        player.hitFlashTimer = player.HIT_FLASH_DUR;
        Deactivate();
        return;
      }

      // Off screen — deactivate (no wall check — passes right through)
      if (xPos < -100 || yPos < -100 || yPos > height + 100)
        Deactivate();
    }
  }

  void Deactivate()
  {
    active       = false;
    currentAlpha = unrenderedAlpha;
    xPos         = -500;
    yPos         = -500;
  }
}

// ── Global scene objects (shared across both waves) ──────────────────────────
Wall   wl;
Wave   wv;
Forest fr;
Cloud  c1, c2;
Torche t1, t2, t3, t4;
Player player;

// Wave 1 enemies
Goblin[] goblins;
Ogre[]   ogres;
Orc[]    orcs;

// Wave 2 enemies
BowTroll[]      bowTrolls;
CrossbowTroll[] crossbowTrolls;

// Wave 3 enemies
Boss boss;
Goblin[] w3goblins;
Orc[]    w3orcs;
Ogre[]   w3ogres;
BowTroll[]      w3bowTrolls;
CrossbowTroll[] w3crossbows;

float[] lanes = { 182, 294, 405, 519, 632 };

// ─────────────────────────────────────────────────────────────────────────────
// Called from Boss.Move() each time it loses 5 HP — spawns 3 melee + 2 ranged
void SpawnPhaseMinions()
{
  // Reset ALL pool slots so old enemies don't linger
  float parkX = width + 3000;
  for (int i = 0; i < 20; i++) {
    w3goblins[i].speed = 0; w3goblins[i].hp = 0; w3goblins[i].xPos = parkX;
    w3orcs[i].speed      = 0; w3orcs[i].hp      = 0; w3orcs[i].xPos      = parkX;
    w3ogres[i].speed     = 0; w3ogres[i].hp     = 0; w3ogres[i].xPos     = parkX;
    w3bowTrolls[i].speed = 0; w3bowTrolls[i].hp = 0; w3bowTrolls[i].xPos = parkX;
    w3crossbows[i].speed = 0; w3crossbows[i].hp = 0; w3crossbows[i].xPos = parkX;
  }

  // Randomise enemy type per spawn slot and spread across random lanes/positions
  // Track next free slot in each pool
  int gi=0, oi=0, og=0, bt=0, cb=0;
  for (int n = 0; n < 20; n++) {
    int   laneIdx = (int)random(5);
    float spawnX  = width + 80 + (int)random(50, 220) + n * random(80, 180);
    float spawnY  = lanes[laneIdx];

    // Random type: weighted — more melee than ranged
    float r = random(1);
    if (r < 0.30 && gi < 20) {
      w3goblins[gi].xPos=spawnX; w3goblins[gi].yPos=spawnY;
      w3goblins[gi].hp=w3goblins[gi].maxHp; w3goblins[gi].speed=1.32; gi++;
    } else if (r < 0.55 && oi < 20) {
      w3orcs[oi].xPos=spawnX; w3orcs[oi].yPos=spawnY;
      w3orcs[oi].hp=w3orcs[oi].maxHp; w3orcs[oi].speed=1.05; oi++;
    } else if (r < 0.70 && og < 20) {
      w3ogres[og].xPos=spawnX; w3ogres[og].yPos=spawnY;
      w3ogres[og].hp=w3ogres[og].maxHp; w3ogres[og].speed=0.79; og++;
    } else if (r < 0.85 && bt < 20) {
      w3bowTrolls[bt].xPos=spawnX; w3bowTrolls[bt].yPos=spawnY;
      w3bowTrolls[bt].hp=w3bowTrolls[bt].maxHp; w3bowTrolls[bt].speed=0.94;
      w3bowTrolls[bt].arrow.Deactivate(); w3bowTrolls[bt].ResetShootTimer(); bt++;
    } else if (cb < 20) {
      w3crossbows[cb].xPos=spawnX; w3crossbows[cb].yPos=spawnY;
      w3crossbows[cb].hp=w3crossbows[cb].maxHp; w3crossbows[cb].speed=0.75;
      w3crossbows[cb].arrow.Deactivate(); w3crossbows[cb].ResetShootTimer(); cb++;
    }
  }
}


class Game
{
  boolean isActive  = false;
  boolean isPaused  = false;
  Button  backButton;
  Button  pauseButton;
  Button  winButton;

  // ── Wave state ──────────────────────────────────────────
  int  currentWave   = 1;   // 1-10
  boolean waveDone   = false;  // wave 1 cleared, showing transition
  int  transTimer    = 0;
  int  TRANS_SHOW    = 180;
    // 3s of "Wave 2" text before spawning
  int  TRANS_FADE_END = 240;   // then fade

  // ── Intro / spawn timers ────────────────────────────────
  int  introTimer    = 0;
  int  FADE_START    = 90;
  int  FADE_END      = 150;
  int  SPAWN_START   = 210;  // 1s after text fades (FADE_END=150)

  int  spawnTimer    = 0;
  int  SPAWN_INTERVAL = 300;
  int  nextSpawnIn    = 0;  // frames until next batch (randomised 3-5s)
  int  spawnedCount  = 0;
  int  MAX_SPAWNED   = 20;
  int  waveMaxSpawned   = 20;  // set per wave
  int  waveSpawnInterval = 300; // set per wave

  Game()
  {
    InitScene();
    InitWave1Pool();

    backButton             = new Button(10, 10, 50, 50, color(90, 40, 10));
    backButton.name        = "X";
    backButton.textColor   = color(255, 220, 80);
    backButton.hoverColor  = color(160, 80, 20);
    backButton.normalColor = color(90, 40, 10);
    backButton.textSize    = 30;

    pauseButton             = new Button(68, 10, 50, 50, color(90, 40, 10));
    pauseButton.name        = "II";
    pauseButton.textColor   = color(255, 220, 80);
    pauseButton.hoverColor  = color(160, 80, 20);
    pauseButton.normalColor = color(90, 40, 10);
    pauseButton.textSize    = 22;


    winButton             = new Button(width/2 - 110, height/2 + 100, 220, 52, color(90, 40, 10));
    winButton.name        = "End Credits";
    winButton.textColor   = color(255, 220, 80);
    winButton.hoverColor  = color(160, 80, 20);
    winButton.normalColor = color(90, 40, 10);
    winButton.textSize    = 18;
  }

  void InitScene()
  {
    wl = new Wall();
    wl.LoadBarSprites();
    wv = new Wave();
    fr = new Forest();
    c1 = new Cloud(380, -300,          0.5);
    c2 = new Cloud(620, height + 300, -0.5);
    t1 = new Torche(90, 55);
    t2 = new Torche(231, 220);
    t3 = new Torche(231, 558);
    t4 = new Torche(90, 718);
    player = new Player(92, 400);
  }

  // ── Shared pool — all normal wave pools use this ────────
  // Per-wave difficulty params — call after InitWavePool()
  void ApplyWaveParams()
  {
    // MAX_SPAWNED: total enemies per wave. SPAWN_INTERVAL: frames between batches.
    // Wave:          1    2    3    4    5    6    7    8    9
    int[] maxS  = { 15,  20,  25,  15,  10,  20,  25,  25,  32 };
    int[] intv  = { 240, 210, 190, 320, 320, 290, 260, 240, 220 };
    int idx = constrain(currentWave - 1, 0, maxS.length - 1);
    MAX_SPAWNED    = maxS[idx];
    SPAWN_INTERVAL = intv[idx];
    spawnedCount   = 0;
    spawnTimer     = 0;
    nextSpawnIn    = 0;  // fire first batch immediately after intro
  }

  void InitWavePool()
  {
    float parkX = width + 3000;
    goblins        = new Goblin[20];
    orcs           = new Orc[20];
    ogres          = new Ogre[20];
    bowTrolls      = new BowTroll[20];
    crossbowTrolls = new CrossbowTroll[20];
    for (int i = 0; i < 20; i++) {
      goblins[i]        = new Goblin(parkX, lanes[i%5]);        goblins[i].speed        = 0;
      orcs[i]           = new Orc(parkX, lanes[i%5]);           orcs[i].speed           = 0;
      ogres[i]          = new Ogre(parkX, lanes[i%5]);          ogres[i].speed          = 0;
      bowTrolls[i]      = new BowTroll(parkX, lanes[i%5]);      bowTrolls[i].speed      = 0;
      crossbowTrolls[i] = new CrossbowTroll(parkX, lanes[i%5]); crossbowTrolls[i].speed = 0;
    }
  }

  void InitWave1Pool() { InitWavePool(); ApplyWaveParams(); }

  void InitWave2Pool() { InitWavePool(); }

  // ── Wave 10: Boss fight ──────────────────────────────────
  void InitWave10Pool()
  {
    boss         = new Boss(width + 80, lanes[2]);
    w3goblins    = new Goblin[20];
    w3orcs       = new Orc[20];
    w3ogres      = new Ogre[20];
    w3bowTrolls  = new BowTroll[20];
    w3crossbows  = new CrossbowTroll[20];
    float parkX10 = width + 3000;
    for (int i = 0; i < 20; i++) {
      w3goblins[i]   = new Goblin(parkX10, lanes[i%5]);   w3goblins[i].speed   = 0;
      w3orcs[i]      = new Orc(parkX10, lanes[i%5]);      w3orcs[i].speed      = 0;
      w3ogres[i]     = new Ogre(parkX10, lanes[i%5]);     w3ogres[i].speed     = 0;
      w3bowTrolls[i] = new BowTroll(parkX10, lanes[i%5]); w3bowTrolls[i].speed = 0;
      w3crossbows[i] = new CrossbowTroll(parkX10, lanes[i%5]); w3crossbows[i].speed = 0;
    }
    spawnedCount = 1;
    spawnTimer   = 0;
  }


  // ── Batch spawning ────────────────────────────────────

  // ── Count enemies currently alive on the field ───────────
  int CountActiveEnemies()
  {
    int count = 0;
    for (int i = 0; i < 20; i++) {
      if (goblins[i].hp > 0        && goblins[i].speed > 0)        count++;
      if (orcs[i].hp > 0           && orcs[i].speed > 0)           count++;
      if (ogres[i].hp > 0          && ogres[i].speed > 0)          count++;
      if (bowTrolls[i].hp > 0      && bowTrolls[i].speed > 0)      count++;
      if (crossbowTrolls[i].hp > 0 && crossbowTrolls[i].speed > 0) count++;
    }
    return count;
  }

  void ReleaseBatch()
  {
    if (spawnedCount >= MAX_SPAWNED) return;
    int onField   = CountActiveEnemies();
    int fieldCap  = 8;
    if (onField >= fieldCap) return;
    int maxCanAdd = min(fieldCap - onField, MAX_SPAWNED - spawnedCount);
    int batchSize = min((int)random(1, 6), maxCanAdd);  // 1-5 but never exceed field cap

    int[] laneOrder = {0,1,2,3,4};
    for (int i = 4; i > 0; i--) {
      int j = (int)random(i+1);
      int tmp = laneOrder[i]; laneOrder[i] = laneOrder[j]; laneOrder[j] = tmp;
    }
    ArrayList<Integer> usedLanes = new ArrayList<Integer>();
    int laneIdx = 0;

    for (int b = 0; b < batchSize; b++)
    {
      float spawnX = width + 120 + b * 320 + random(0, 60);

      int chosenLane = -1;
      for (int t = 0; t < 5; t++) {
        int candidate = laneOrder[(laneIdx + t) % 5];
        if (!usedLanes.contains(candidate)) { chosenLane = candidate; laneIdx = laneIdx + t + 1; break; }
      }
      if (chosenLane == -1) break;
      usedLanes.add(chosenLane);
      float spawnY = lanes[chosenLane];

      // Wave composition:
      // 0=goblin 1=orc 2=ogre 3=bowtroll 4=crossbow
      int type = -1;
      float r = random(1);
      // goblin=40% orc=35% ogre=25% | bowtroll=60% crossbow=40%
      if      (currentWave == 1) { type = 0; }
      else if (currentWave == 2) { type = (r < 0.53) ? 0 : 1; }  // g53% o47% (40:35 ratio)
      else if (currentWave == 3) { type = (r < 0.40) ? 0 : (r < 0.75) ? 1 : 2; }  // g40% o35% ogre25%
      else if (currentWave == 4) { type = 3; }
      else if (currentWave == 5) { type = 4; }
      else if (currentWave == 6) { type = (r < 0.60) ? 3 : 4; }  // bt60% cb40%
      else if (currentWave == 7) { // more melee: g40% o35% ogre25% of melee(60%), bt60% cb40% of ranged(40%)
        type = (r < 0.24) ? 0 : (r < 0.45) ? 1 : (r < 0.60) ? 2 : (r < 0.84) ? 3 : 4;
      }
      else if (currentWave == 8) { // more ranged: melee40% ranged60%
        type = (r < 0.16) ? 0 : (r < 0.30) ? 1 : (r < 0.40) ? 2 : (r < 0.76) ? 3 : 4;
      }
      else if (currentWave == 9) { // equal 50/50
        type = (r < 0.20) ? 0 : (r < 0.375) ? 1 : (r < 0.50) ? 2 : (r < 0.80) ? 3 : 4;
      }

      boolean spawned = false;
      for (int i = 0; i < 20 && !spawned; i++) {
        if      (type==0 && (goblins[i].speed==0||goblins[i].hp<=0))              { goblins[i].xPos=spawnX; goblins[i].yPos=spawnY; goblins[i].hp=goblins[i].maxHp; goblins[i].speed=1.32; spawned=true; }
        else if (type==1 && (orcs[i].speed==0||orcs[i].hp<=0))                    { orcs[i].xPos=spawnX; orcs[i].yPos=spawnY; orcs[i].hp=orcs[i].maxHp; orcs[i].speed=1.05; spawned=true; }
        else if (type==2 && (ogres[i].speed==0||ogres[i].hp<=0))                  { ogres[i].xPos=spawnX; ogres[i].yPos=spawnY; ogres[i].hp=ogres[i].maxHp; ogres[i].speed=0.79; spawned=true; }
        else if (type==3 && (bowTrolls[i].speed==0||bowTrolls[i].hp<=0))          { bowTrolls[i].xPos=spawnX; bowTrolls[i].yPos=spawnY; bowTrolls[i].hp=bowTrolls[i].maxHp; bowTrolls[i].speed=0.94; bowTrolls[i].arrow.Deactivate(); bowTrolls[i].ResetShootTimer(); spawned=true; }
        else if (type==4 && (crossbowTrolls[i].speed==0||crossbowTrolls[i].hp<=0)){ crossbowTrolls[i].xPos=spawnX; crossbowTrolls[i].yPos=spawnY; crossbowTrolls[i].hp=crossbowTrolls[i].maxHp; crossbowTrolls[i].speed=0.75; crossbowTrolls[i].arrow.Deactivate(); crossbowTrolls[i].ResetShootTimer(); spawned=true; }
      }
      if (spawned) spawnedCount++;
    }
  }

  // ── All enemies cleared for current wave ────────────────
  boolean waveClear()
  {
    if (spawnedCount < MAX_SPAWNED) return false;
    for (int i = 0; i < 20; i++) {
      if (goblins[i].speed>0        && goblins[i].hp>0)        return false;
      if (orcs[i].speed>0           && orcs[i].hp>0)           return false;
      if (ogres[i].speed>0          && ogres[i].hp>0)          return false;
      if (bowTrolls[i].speed>0      && bowTrolls[i].hp>0)      return false;
      if (crossbowTrolls[i].speed>0 && crossbowTrolls[i].hp>0) return false;
    }
    return true;
  }

  void HandleGame()
  {
    if (isActive) {
      Render();
      backButton.Hover();
      pauseButton.Hover();
      if (currentWave == 10 && boss != null && boss.IsCleared()) winButton.Hover();
    }
  }

  void Render()
  {
    background(198, 225, 116);

    // ── Intro timer + spawn ──────────────────────────────
    if (!isPaused) {  // ── Only run game logic when not paused ──
    if (!waveDone) {
      if (introTimer <= SPAWN_START) introTimer++;
      if (introTimer >= SPAWN_START) {
        if (currentWave != 10) {
          spawnTimer++;
          if (spawnTimer >= nextSpawnIn) {
            // Set next fire time FIRST to prevent double-firing
            nextSpawnIn = spawnTimer + (int)random(180, 301);
            ReleaseBatch();
          }
        }
      }
      if (currentWave < 10 && waveClear()) {
        waveDone   = true;
        transTimer = 0;
        wl.hp = min(wl.hp + 1, wl.maxHP);
        wl.TriggerHealFlash();
      }
    } else {
      transTimer++;
      if (transTimer >= TRANS_FADE_END) {
        waveDone   = false;
        spawnTimer = 0;
        if (currentWave < 9) {
          currentWave++;
          introTimer = SPAWN_START;
          InitWavePool();
          ApplyWaveParams();
          nextSpawnIn = 0;
        } else if (currentWave == 9) {
          currentWave = 10;
          introTimer  = SPAWN_START;
          InitWave10Pool();
          nextSpawnIn = 0;
        }
      }
    }

    }  // end !isPaused

    // Layer 1: Lanes
    wl.RenderLanes();

    // Layer 2: Waves
    wv.Render();

    // Layer 3: Enemies (behind wall)
    hint(ENABLE_STROKE_PURE);
    if (currentWave < 10) {
      for (int i = 0; i < 20; i++) {
        if (!isPaused) {
          goblins[i].Move(); orcs[i].Move(); ogres[i].Move();
          bowTrolls[i].Move(); crossbowTrolls[i].Move();
        }
        goblins[i].RenderBody(); orcs[i].RenderBody(); ogres[i].RenderBody();
        bowTrolls[i].RenderBody(); crossbowTrolls[i].RenderBody();
      }
      DoSeparation();
    } else {
      if (!isPaused) { boss.Move(); boss.bFireball.Move(); }
      for (int i = 0; i < 20; i++) {
        if (!isPaused) {
          w3goblins[i].Move(); w3orcs[i].Move(); w3ogres[i].Move();
          w3bowTrolls[i].Move(); w3crossbows[i].Move();
        }
        w3goblins[i].RenderBody(); w3orcs[i].RenderBody(); w3ogres[i].RenderBody();
        w3bowTrolls[i].RenderBody(); w3crossbows[i].RenderBody();
      }
      boss.RenderBody();  // render boss LAST so it's on top
    }

    // Layer 4: Wall (over enemies)
    wl.RenderBack();
    wl.Render();

    // Layer 5: Forest (over wall)
    fr.Render();

    // Layer 6: Arrows
    if (currentWave < 10) { for (int i = 0; i < 20; i++) { bowTrolls[i].RenderArrow(); crossbowTrolls[i].RenderArrow(); } }
    else { for (int i = 0; i < 10; i++) { w3bowTrolls[i].RenderArrow(); w3crossbows[i].RenderArrow(); } }

    // Layer 7: Torches
    t1.Render(); t2.Render(); t3.Render(); t4.Render();

    // Layer 8: Clouds
    c1.Render(); c1.Move();
    c2.Render(); c2.Move();
    float minSep = 220, dx = c2.xPos - c1.xPos;
    if (abs(dx) < minSep) {
      float push = (minSep - abs(dx)) / 2.0 + 1;
      if (dx >= 0) { c1.xPos -= push; c2.xPos += push; }
      else         { c1.xPos += push; c2.xPos -= push; }
      c1.xPos = constrain(c1.xPos, 280, 730);
      c2.xPos = constrain(c2.xPos, 280, 730);
    }

    // Fireball collision
    if (!isPaused && fireBall.active) {
      boolean fbHit = false;
      if (currentWave < 10) {
        outerN: for (int i = 0; i < 20; i++) {
          if (goblins[i].CheckHit(fireBall.xPos,fireBall.yPos))        { if(goblins[i].Hit())        { goblins[i].speed=0;        PlayRandom(sfxGoblin); }        fireBall.Deactivate(); fbHit=true; break outerN; }
          if (orcs[i].CheckHit(fireBall.xPos,fireBall.yPos))           { if(orcs[i].Hit())           { orcs[i].speed=0;           PlayRandom(sfxOrc); }           fireBall.Deactivate(); fbHit=true; break outerN; }
          if (ogres[i].CheckHit(fireBall.xPos,fireBall.yPos))          { if(ogres[i].Hit())          { ogres[i].speed=0;          PlayRandom(sfxOgre); }          fireBall.Deactivate(); fbHit=true; break outerN; }
          if (bowTrolls[i].CheckHit(fireBall.xPos,fireBall.yPos))      { if(bowTrolls[i].Hit())      { bowTrolls[i].speed=0;      PlayRandom(sfxBowTroll); }      fireBall.Deactivate(); fbHit=true; break outerN; }
          if (crossbowTrolls[i].CheckHit(fireBall.xPos,fireBall.yPos)) { if(crossbowTrolls[i].Hit()) { crossbowTrolls[i].speed=0; PlayRandom(sfxCrossBowTroll); } fireBall.Deactivate(); fbHit=true; break outerN; }
        }
      } else {
        if (!fbHit && boss.CheckHit(fireBall.xPos, fireBall.yPos)) {
          boss.Hit(); fireBall.Deactivate(); fbHit = true;
        }
        if (!fbHit) {
          outer10: for (int i = 0; i < 20; i++) {
            if (w3goblins[i].CheckHit(fireBall.xPos,fireBall.yPos))  { if(w3goblins[i].Hit())  { w3goblins[i].speed=0;  PlayRandom(sfxGoblin);        boss.NotifyMinionKilled(); } fireBall.Deactivate(); fbHit=true; break outer10; }
            if (w3orcs[i].CheckHit(fireBall.xPos,fireBall.yPos))     { if(w3orcs[i].Hit())     { w3orcs[i].speed=0;     PlayRandom(sfxOrc);           boss.NotifyMinionKilled(); } fireBall.Deactivate(); fbHit=true; break outer10; }
            if (w3ogres[i].CheckHit(fireBall.xPos,fireBall.yPos))    { if(w3ogres[i].Hit())    { w3ogres[i].speed=0;    PlayRandom(sfxOgre);          boss.NotifyMinionKilled(); } fireBall.Deactivate(); fbHit=true; break outer10; }
            if (w3bowTrolls[i].CheckHit(fireBall.xPos,fireBall.yPos)){ if(w3bowTrolls[i].Hit()){ w3bowTrolls[i].speed=0; PlayRandom(sfxBowTroll);     boss.NotifyMinionKilled(); } fireBall.Deactivate(); fbHit=true; break outer10; }
            if (w3crossbows[i].CheckHit(fireBall.xPos,fireBall.yPos)){ if(w3crossbows[i].Hit()){ w3crossbows[i].speed=0; PlayRandom(sfxCrossBowTroll); boss.NotifyMinionKilled(); } fireBall.Deactivate(); fbHit=true; break outer10; }
          }
        }
      }
    }

    // Boss fireball hits player
    if (!isPaused && currentWave == 10 && boss != null && !boss.dead) {
      if (boss.bFireball.CheckHit(player.xPos, player.yPos, 28)) {
        player.TakeDamage();
        player.hitFlashTimer = player.HIT_FLASH_DUR;
        boss.bFireball.Deactivate();
      }
    }

    // Layer 9: Fireball + player
    fireBall.Render();
    player.Render();
    if (!isPaused) player.Move();
    // Layer 10: Boss fireball — top of everything
    if (currentWave == 10 && boss != null) boss.bFireball.Render();

    // Health bars
    if (currentWave < 10) {
      for (int i = 0; i < 20; i++) {
        goblins[i].DrawHealthBar(); orcs[i].DrawHealthBar(); ogres[i].DrawHealthBar();
        bowTrolls[i].DrawHealthBar(); crossbowTrolls[i].DrawHealthBar();
      }
    } else {
      boss.DrawHealthBar();
      for (int i = 0; i < 20; i++) {
        w3goblins[i].DrawHealthBar(); w3orcs[i].DrawHealthBar(); w3ogres[i].DrawHealthBar();
        w3bowTrolls[i].DrawHealthBar(); w3crossbows[i].DrawHealthBar();
      }
    }
    wl.DrawHealthBar();
    wl.DrawHealFlash();

    // ── Wave label top-right with backdrop ──────────────
    textSize(20); textAlign(CENTER, CENTER);
    float wlabelW = textWidth("Wave " + currentWave) + 28;
    float wlabelX = width - wlabelW - 8;
    float wlabelY = 8;
    float wlabelH = 34;
    fill(45, 18, 5, 210); noStroke();
    rect(wlabelX, wlabelY, wlabelW, wlabelH, 6);
    stroke(200, 160, 50); strokeWeight(1);
    rect(wlabelX, wlabelY, wlabelW, wlabelH, 6); noStroke();
    fill(0, 0, 0, 160); text("Wave " + currentWave, wlabelX + wlabelW/2 + 1, wlabelY + wlabelH/2 + 1);
    fill(255, 220, 80);  text("Wave " + currentWave, wlabelX + wlabelW/2,     wlabelY + wlabelH/2);

    // ── Intro "Wave 1" text ───────────────────────────────
    if (introTimer < FADE_END && currentWave == 1) {
      int alpha = (introTimer < FADE_START) ? 255
        : int(255 * (1.0 - (float)(introTimer - FADE_START) / (FADE_END - FADE_START)));
      DrawWaveText("Wave 1", alpha);
    }

    // ── Wave transition text + boss win screen ──────────
    if (waveDone) {
      int nextW = currentWave + 1;
      String nextLabel = (nextW == 10) ? "Final Wave" : "Wave " + nextW;
      int alpha = (transTimer < TRANS_SHOW) ? 255
        : int(255 * (1.0 - (float)(transTimer - TRANS_SHOW) / (TRANS_FADE_END - TRANS_SHOW)));
      alpha = constrain(alpha, 0, 255);
      DrawWaveText(nextLabel, alpha);
    }

    // ── Boss defeated = Victory! ──────────────────────────
    if (currentWave == 10 && boss != null && boss.IsCleared()) {
      DrawVictory();
    }

    // ── Respawn countdown above dead sprite ─────────────
    if (player.dead && player.deathX > 0) {
      int secsLeft = ceil((float)(player.RESPAWN_FRAMES - player.respawnTimer) / 60.0);
      float mx = player.deathX, my = player.deathY;
      textAlign(CENTER, CENTER); textSize(22);
      float tw = textWidth(secsLeft + "...") + 18;
      fill(0,0,0,160); noStroke(); rect(mx - tw/2, my - 100, tw, 28, 6);
      fill(0,0,0,180); text(secsLeft + "...", mx + 2, my - 86);
      fill(255,220,80); text(secsLeft + "...", mx,     my - 88);
    }

    // X button
    backButton.Render();
    pauseButton.name = isPaused ? ">" : "II";
    pauseButton.Render();
    if (isPaused && !wl.broken) DrawPaused();

    // ── Game Over: wall destroyed only ────────────────────
    if (wl.broken) {
      DrawGameOver("Your wall has crumbled to the green :(");
    }
  }

  void DrawWaveText(String label, int alpha)
  {
    textSize(72);
    float tw = textWidth(label);
    float bw = tw + 80, bh = 90;
    fill(0, 0, 0, alpha / 2); noStroke();
    rect(width/2 - bw/2, height/2 - bh/2, bw, bh, 16);
    textAlign(CENTER, CENTER);
    fill(0, 0, 0, alpha);      text(label, width/2 + 3, height/2 + 3);
    fill(255, 220, 80, alpha); text(label, width/2, height/2);
  }

  void DrawVictory()
  {
    // Dim overlay
    fill(20, 8, 0, 210); noStroke(); rect(0, 0, width, height);

    // Panel — same dimensions/style as game over
    float px = width/2 - 290, py = height/2 - 195, pw = 580, ph = 390;
    fill(0, 0, 0, 110); rect(px+7, py+7, pw, ph, 20);
    fill(45, 18, 5); stroke(200, 160, 50); strokeWeight(3); rect(px, py, pw, ph, 20); noStroke();
    noFill(); stroke(255, 220, 80, 80); strokeWeight(1); rect(px+8, py+8, pw-16, ph-16, 14); noStroke();

    // Lemon graphic (drawn in code)
    DrawLemon(width/2, py + 68);

    // Title
    textAlign(CENTER, CENTER); textSize(58);
    fill(0, 0, 0, 200); text("You Win!", width/2 + 3, py + 148);
    fill(255, 220, 80);  text("You Win!", width/2,     py + 145);

    // Subtitle
    textSize(17);
    fill(0, 0, 0, 170); text("The boss has been squeezed!", width/2 + 2, py + 198);
    fill(230, 210, 160); text("The boss has been squeezed!", width/2,     py + 196);

    textSize(14);
    fill(180, 140, 80);
    text("Your wall still stands... for now.", width/2, py + 226);

    // "Return to Menu" button
    winButton.xPos = width/2 - 110;
    winButton.yPos = py + 260;
    winButton.Render();
  }

  void DrawLemon(float cx, float cy)
  {
    // Lemon body — yellow oval
    noStroke();
    fill(255, 220, 20, 200);
    ellipse(cx, cy, 80, 56);
    // Highlight
    fill(255, 250, 160, 160);
    ellipse(cx - 10, cy - 8, 30, 18);
    // Nub left
    fill(255, 200, 10, 200);
    ellipse(cx - 42, cy, 16, 12);
    // Nub right
    ellipse(cx + 42, cy, 16, 12);
    // Outline
    noFill(); stroke(200, 160, 0, 180); strokeWeight(2);
    ellipse(cx, cy, 80, 56);
    ellipse(cx - 42, cy, 16, 12);
    ellipse(cx + 42, cy, 16, 12);
    noStroke();
    // Leaf
    fill(80, 180, 40, 200);
    beginShape();
    vertex(cx + 10, cy - 28);
    bezierVertex(cx + 30, cy - 50, cx + 55, cy - 45, cx + 38, cy - 22);
    bezierVertex(cx + 20, cy - 20, cx + 12, cy - 24, cx + 10, cy - 28);
    endShape(CLOSE);
    fill(100, 210, 60, 160);
    beginShape();
    vertex(cx + 12, cy - 29);
    bezierVertex(cx + 28, cy - 46, cx + 48, cy - 40, cx + 36, cy - 24);
    bezierVertex(cx + 22, cy - 22, cx + 14, cy - 25, cx + 12, cy - 29);
    endShape(CLOSE);
  }

  void DrawPaused()
  {
    fill(20, 8, 0, 190); noStroke(); rect(0, 0, width, height);
    float px = width/2 - 280, py = height/2 - 155, pw = 560, ph = 310;
    fill(0, 0, 0, 100); rect(px+6, py+6, pw, ph, 20);
    fill(45, 18, 5); stroke(200, 160, 50); strokeWeight(3); rect(px, py, pw, ph, 20); noStroke();
    noFill(); stroke(255, 220, 80, 80); strokeWeight(1); rect(px+8, py+8, pw-16, ph-16, 14); noStroke();
    textAlign(CENTER, CENTER); textSize(68);
    fill(0, 0, 0, 180); text("Paused", width/2 + 3, height/2 - 68);
    fill(255, 220, 80);  text("Paused", width/2,     height/2 - 71);
    textSize(19);
    fill(0, 0, 0, 160); text("Press || to resume", width/2 + 2, height/2 + 2);
    fill(230, 210, 160); text("Press || to resume", width/2,     height/2);
    backButton.Render();
    pauseButton.Render();
  }

  void DrawGameOver(String subtitle)
  {
    fill(20, 8, 0, 200); noStroke(); rect(0, 0, width, height);
    float px = width/2 - 280, py = height/2 - 155, pw = 560, ph = 310;
    fill(0, 0, 0, 100); rect(px+6, py+6, pw, ph, 20);
    fill(45, 18, 5); stroke(200, 160, 50); strokeWeight(3); rect(px, py, pw, ph, 20); noStroke();
    noFill(); stroke(255, 220, 80, 80); strokeWeight(1); rect(px+8, py+8, pw-16, ph-16, 14); noStroke();
    textAlign(CENTER, CENTER); textSize(68);
    fill(0, 0, 0, 180); text("Game over.", width/2 + 3, height/2 - 68);
    fill(255, 220, 80);  text("Game over.", width/2, height/2 - 71);
    textSize(19);
    fill(0, 0, 0, 160); text(subtitle, width/2 + 2, height/2 + 2);
    fill(230, 210, 160); text(subtitle, width/2, height/2);
    textSize(16); fill(180, 140, 80); text("Press X to restart", width/2, height/2 + 68);
    backButton.Render();
    pauseButton.name = isPaused ? ">" : "II";
    pauseButton.Render();
    if (isPaused && !wl.broken) DrawPaused();
  }


  // ── Prevent enemies overlapping — lane-aware horizontal push ─
  void DoSeparation()
  {
    int POOL = 20;
    float MIN_DIST = 80; // minimum px between centres in same lane

    // Build flat list of all active enemies
    float[] xs       = new float[POOL * 5];
    float[] ys       = new float[POOL * 5];
    float[] spds     = new float[POOL * 5];
    int[]   pType    = new int[POOL * 5];
    int[]   pIdx     = new int[POOL * 5];
    int n = 0;

    for (int i = 0; i < POOL; i++) {
      if (goblins[i].hp > 0)        { xs[n]=goblins[i].xPos;        ys[n]=goblins[i].yPos;        spds[n]=goblins[i].speed;        pType[n]=0; pIdx[n]=i; n++; }
      if (orcs[i].hp > 0)           { xs[n]=orcs[i].xPos;           ys[n]=orcs[i].yPos;           spds[n]=orcs[i].speed;           pType[n]=1; pIdx[n]=i; n++; }
      if (ogres[i].hp > 0)          { xs[n]=ogres[i].xPos;          ys[n]=ogres[i].yPos;          spds[n]=ogres[i].speed;          pType[n]=2; pIdx[n]=i; n++; }
      if (bowTrolls[i].hp > 0)      { xs[n]=bowTrolls[i].xPos;      ys[n]=bowTrolls[i].yPos;      spds[n]=bowTrolls[i].speed;      pType[n]=3; pIdx[n]=i; n++; }
      if (crossbowTrolls[i].hp > 0) { xs[n]=crossbowTrolls[i].xPos; ys[n]=crossbowTrolls[i].yPos; spds[n]=crossbowTrolls[i].speed; pType[n]=4; pIdx[n]=i; n++; }
    }

    // Multiple passes for stability
    for (int pass = 0; pass < 3; pass++) {
      for (int a = 0; a < n; a++) {
        if (spds[a] <= 0) continue;
        for (int b = a + 1; b < n; b++) {
          if (spds[b] <= 0) continue;
          // Only separate enemies in the same lane (within 30px vertically)
          if (abs(ys[a] - ys[b]) > 30) continue;
          float dx = xs[a] - xs[b];
          float dist = abs(dx);
          if (dist < MIN_DIST && dist > 0.1) {
            float overlap = (MIN_DIST - dist);
            // Push the one in front (larger x = further right = behind in march)
            // push both apart along x only
            if (dx > 0) {
              // a is to the right (spawned later), push it right
              xs[a] += overlap * 0.6;
              xs[b] -= overlap * 0.4;
            } else {
              xs[b] += overlap * 0.6;
              xs[a] -= overlap * 0.4;
            }
          }
        }
      }
    }

    // Write positions back
    for (int i = 0; i < n; i++) {
      ApplyPos(pType[i], pIdx[i], xs[i]);
    }
  }

  void ApplyPos(int type, int idx, float x)
  {
    if      (type==0) goblins[idx].xPos        = x;
    else if (type==1) orcs[idx].xPos           = x;
    else if (type==2) ogres[idx].xPos          = x;
    else if (type==3) bowTrolls[idx].xPos      = x;
    else if (type==4) crossbowTrolls[idx].xPos = x;
  }

  void OnMouseReleased()
  {
    if (isActive) {
      // Pause button
      if (pauseButton.Onclick()) {
        isPaused = !isPaused;
        if (isPaused) gameMusic.pause();
        else          gameMusic.loop();
        return;
      }
      // Win screen "Return to Menu" button
      if (currentWave == 10 && boss != null && boss.IsCleared()) {
        if (winButton.Onclick()) {
          winButton.isHovered = false;
          backButton.isHovered = false;
          isActive = false;
          // Go to end credits
          credits.isActive = true;
          credits.scrollY  = 0;
          // Reset game state for when player returns
          wl = new Wall(); wl.LoadBarSprites();
          player = new Player(92, 400);
          fireBall.Deactivate();
          introTimer = 0; currentWave = 1; waveDone = false; transTimer = 0;
          boss = null; w3goblins = null; w3orcs = null; w3ogres = null;
          w3bowTrolls = null; w3crossbows = null;
          transTimer = 0;
          InitWave1Pool();
          return;
        }
      }
      if (backButton.Onclick()) {
        backButton.isHovered = false;
        isActive  = false;
        isPaused  = false;
        menu.isActive = true;
        // Full reset
        wl = new Wall();
    wl.LoadBarSprites();
        player = new Player(92, 400);
        fireBall.Deactivate();
        introTimer  = 0;
        currentWave = 1;
        waveDone    = false;
        boss        = null;
        w3goblins = null; w3orcs = null; w3ogres = null; w3bowTrolls = null; w3crossbows = null;
        transTimer  = 0;
        InitWave1Pool();
      }
    }
  }
}

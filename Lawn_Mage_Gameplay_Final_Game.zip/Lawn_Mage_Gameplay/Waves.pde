class Wave 
{
  Wave() {}

  void wavyLine(float startX, float endX, float baseY, float amp, float freq)
  {
    beginShape();
    for (float x = startX; x <= endX; x += 6)
    {
      float y = baseY + sin((x - startX) * freq) * amp;
      vertex(x, y);
    }
    endShape();
  }

  void Render() 
  {
    // ── TOP WATER BAND ────────────────────────────────────
    noStroke();
    fill(42, 110, 175);
    rect(231, -2, 570, 127);

    noFill();

    // 2 short wavy lines at random-ish positions
    stroke(100, 180, 235);
    strokeWeight(5);
    wavyLine(290, 490, 60, 3.5, 0.048);

    stroke(210, 235, 255, 200);
    strokeWeight(4);
    wavyLine(520, 760, 82, 2.5, 0.036);

    stroke(58, 138, 205);
    strokeWeight(5);
    wavyLine(350, 620, 108, 3.0, 0.042);

    // ── BOTTOM WATER BAND ─────────────────────────────────
    noStroke();
    fill(42, 110, 175);
    rect(231, 695, 570, 108);

    noFill();

    stroke(100, 180, 235);
    strokeWeight(5);
    wavyLine(260, 510, 722, 3.5, 0.048);

    stroke(210, 235, 255, 200);
    strokeWeight(4);
    wavyLine(480, 780, 758, 2.5, 0.036);

    stroke(58, 138, 205);
    strokeWeight(5);
    wavyLine(310, 590, 791, 3.0, 0.042);

    noStroke();
  }
}

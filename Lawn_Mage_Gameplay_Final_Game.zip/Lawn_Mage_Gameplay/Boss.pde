// ── Boss — Wave 3 final boss ────────────────────────────────────────────────
// 20 HP. Every 5 HP lost:
//   • Shield activates (simple single ring, no fill)
//   • Boss slides to top lane (odd phases) or bottom lane (even phases)
//   • Bobs up/down slowly there while 5 minions are alive
//   • When 5 minions killed → shield fades, boss resumes moving forward
// No text or numbers on health bar. Feet aligned to lane ground.

class Boss
{
  float xPos, yPos;
  float speed       = 0.55;   // faster when not shielded
  int   hp          = 20;
  int   maxHp       = 20;
  PImage sprite;
  float sw = 200, sh = 200;

  // Current Y position tracking
  float laneY       = 0;

  // Continuous up/down sweep during phase
  float sweepY      = 0;      // current sweep position
  float sweepSpeed  = 1.4;    // pixels per frame up/down
  int   sweepDir    = 1;      // 1 = moving down, -1 = moving up
  float sweepTop    = 182;    // top boundary (lane 0)
  float sweepBottom = 632;    // bottom boundary (lane 4)

  // Phase state
  int   phase              = 0;
  boolean phaseActive      = false;
  int   minionsKilled      = 0;
  int   MINIONS_TO_KILL    = 20;

  // Shield — single clean ring
  boolean shielded    = false;
  float   shieldAlpha = 0;
  float   shieldPulse = 0;

  // Death
  boolean dead           = false;
  boolean deathSoundDone = false;

  float FEET_OFFSET = -53;

  // Projectile
  BossFireball bFireball;

  int shieldShootTimer = 0;
  int shieldShootCD    = 0;  // cooldown while in shield phase
  int normalShootTimer  = 0;
  int normalShootCD     = 0;  // cooldown while moving forward

  Boss(float x, float y)
  {
    xPos      = x;
    yPos      = y;
    laneY     = y;
    sweepY    = y;
    sprite = sprBoss;
    bFireball     = new BossFireball();
    shieldShootCD  = (int)random(180, 360);
    normalShootCD  = (int)random(240, 480);
  }

  void NotifyMinionKilled()
  {
    if (!phaseActive) return;
    minionsKilled++;
    if (minionsKilled >= MINIONS_TO_KILL) {
      phaseActive = false;
      shielded    = false;
      laneY       = sweepY;  // resume from wherever sweep ended
    }
  }

  void Move()
  {
    if (dead) return;

    // ── Trigger new phase ──────────────────────────────
    int phasesShouldBe = (maxHp - hp) / 5;
    if (phasesShouldBe > phase && !phaseActive)
    {
      phase++;
      phaseActive      = true;
      shielded         = true;
      minionsKilled    = 0;
      shieldShootTimer = 0;
      shieldShootCD    = (int)random(120, 240);  // short first delay
      PlayRandom(sfxBoss);
      SpawnPhaseMinions();
    }

    // ── Sweep + shoot during shield phase ─────────────
    if (phaseActive)
    {
      sweepY += sweepSpeed * sweepDir;
      if (sweepY >= sweepBottom) { sweepY = sweepBottom; sweepDir = -1; }
      if (sweepY <= sweepTop)    { sweepY = sweepTop;    sweepDir =  1; }
      yPos  = sweepY;
      laneY = sweepY;
      // Fire during shield phase at fixed crossbow-troll speed
      shieldShootTimer++;
      if (shieldShootTimer >= shieldShootCD) {
        shieldShootTimer = 0;
        shieldShootCD    = (int)random(160, 320);
        bFireball.FireShield(xPos - sw/2, yPos + FEET_OFFSET);
      }
      bFireball.Move();
      return;
    }

    // ── Shoot while moving forward ────────────────────
    normalShootTimer++;
    if (normalShootTimer >= normalShootCD) {
      normalShootTimer = 0;
      normalShootCD    = (int)random(240, 480);
      bFireball.FireShield(xPos - sw/2, yPos + FEET_OFFSET);
    }
    bFireball.Move();

    // ── Normal forward movement ────────────────────────
    xPos -= speed;
    yPos  = laneY;
    if (xPos < 231) {
      wl.hp     = 0;
      wl.broken = true;
      Kill();
    }
  }

  void Kill() { hp = 0; speed = 0; dead = true; }

  void RenderBody()
  {
    if (dead) return;

    float drawY = yPos + FEET_OFFSET;

    // ── Shield: single clean pulsing ring ─────────────
    shieldPulse += 0.06;
    if (shielded) shieldAlpha = min(shieldAlpha + 12, 200);
    else          shieldAlpha = max(shieldAlpha - 16, 0);

    if (shieldAlpha > 0) {
      float r = sw * 0.6 + sin(shieldPulse) * 5;
      noFill();
      stroke(120, 190, 255, shieldAlpha);
      strokeWeight(2.5);
      ellipse(xPos, drawY, r * 2, r * 2);
      noStroke();
    }

    imageMode(CENTER);
    image(sprite, xPos, drawY, sw, sh);
    imageMode(CORNER);
    noTint();
  }

  void DrawHealthBar()
  {
    if (dead) return;
    float drawY = yPos + FEET_OFFSET;
    float barW = 130, barH = 10;
    float bx = xPos - barW/2, by = drawY - sh/2 - 16;

    // Background
    noStroke(); fill(25, 8, 8); rect(bx, by, barW, barH, 3);
    // Fill
    float ratio = (float)hp / maxHp;
    fill(lerpColor(color(220,40,40), color(80,220,60), ratio));
    rect(bx, by, barW * ratio, barH, 3);
    // Phase notch lines every 5 HP
    stroke(0,0,0,180); strokeWeight(1.2);
    for (int i = 1; i < 5; i++) {
      float nx = bx + barW * (i * 5.0 / maxHp);
      line(nx, by+1, nx, by+barH-1);
    }
    noStroke();
    // White border only
    noFill(); stroke(255,255,255,80); strokeWeight(1);
    rect(bx, by, barW, barH, 3); noStroke();
  }

  boolean CheckHit(float fx, float fy)
  {
    if (dead || shielded) return false;
    float drawY = yPos + FEET_OFFSET;
    return dist(fx, fy, xPos, drawY) < sw * 0.46;
  }

  boolean Hit()
  {
    if (dead || shielded) return false;
    hp--;
    if (hp <= 0) {
      hp = 0; speed = 0; dead = true;
      if (!deathSoundDone) {
        deathSoundDone = true;
        sfxBoss[0].stop(); sfxBoss[0].play();
        sfxBoss[1].stop(); sfxBoss[1].play();
        sfxBoss[2].stop(); sfxBoss[2].play();
      }
      return true;
    }
    return false;
  }

  boolean IsCleared() { return dead; }
}

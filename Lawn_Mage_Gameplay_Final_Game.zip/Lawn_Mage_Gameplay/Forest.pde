class Forest 
{
  float offset = 0;

  Forest() {}

  void Render() 
  {
    offset = sin(frameCount * 0.015) * 12;

    noStroke();

    // Forest Up — sways right with +offset
    fill(12, 169, 60);  ellipse(36  + offset, -11, 90, 99);
    fill(35, 136, 59);  ellipse(86  + offset,  -1, 89, 66);
    fill(15, 158, 59);  ellipse(167 + offset, -11, 90, 99);
    fill(18, 117, 26);  ellipse(214 + offset,  13, 86, 69);
    fill(27, 158, 45);  ellipse(263 + offset,   9, 102, 82);
    fill(18, 167, 26);  ellipse(335 + offset,  -1, 100, 95);
    fill(18, 127, 26);  ellipse(388 + offset,  15, 81, 72);
    fill(14, 150, 36);  ellipse(442 + offset, -11, 90, 99);
    fill(18, 127, 26);  ellipse(488 + offset,  22, 76, 72);
    fill(14, 150, 36);  ellipse(547 + offset,   9, 102, 82);
    fill(18, 167, 26);  ellipse(623 + offset,  -1, 100, 95);
    fill(14, 150, 36);  ellipse(693 + offset, -11, 90, 99);
    fill(18, 117, 26);  ellipse(763 + offset,  13, 86, 69);

    // Forest Down — sways opposite with -offset
    fill(14, 150, 36);  ellipse(36  - offset, 802, 90, 99);
    fill(18, 127, 26);  ellipse(86  - offset, 792, 89, 66);
    fill(14, 150, 36);  ellipse(167 - offset, 814, 90, 99);
    fill(18, 117, 26);  ellipse(214 - offset, 803, 86, 69);
    fill(14, 150, 36);  ellipse(263 - offset, 796, 102, 82);
    fill(18, 167, 26);  ellipse(335 - offset, 805, 100, 95);
    fill(18, 127, 26);  ellipse(388 - offset, 801, 81, 72);
    fill(14, 150, 36);  ellipse(418 - offset, 815, 90, 99);
    fill(18, 127, 26);  ellipse(489 - offset, 801, 89, 66);
    fill(14, 150, 36);  ellipse(547 - offset, 804, 102, 82);
    fill(18, 167, 26);  ellipse(623 - offset, 814, 100, 95);
    fill(14, 150, 28);  ellipse(670 - offset, 815, 90, 99);
    fill(18, 127, 60);  ellipse(763 - offset, 798, 76, 72);
  }
}

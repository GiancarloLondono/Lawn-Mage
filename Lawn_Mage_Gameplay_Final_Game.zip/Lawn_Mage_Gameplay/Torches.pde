class Torche 
{
  float xPos, yPos;
  float speed;

  color A = color(254, 0, 36);
  color B = color(255, 157, 2);
  color C = color(255, 240, 5);

  color currentColor;

  float amt1, amt2, amt3;
  float colorSpeed = 0.006;


  Torche(float x, float y) 
  {

    xPos = x;
    yPos = y;

    amt1 = 0.0;
    amt2 = 0.33;
    amt3 = 0.66;
  }

  color flameColor(float t) 
  {
    t = t % 1.0;

    if (t < 0.33) 
    {
      return lerpColor(A, B, t / 0.33);
    } else if (t < 0.66) 
    {
      return lerpColor(B, C, (t - 0.33) / 0.33);
    } else 
    {
      return lerpColor(C, A, (t - 0.66) / 0.34);
    }
  }

  void Render() 
  {

    amt1 = (amt1 + colorSpeed) % 1.0;
    amt2 = (amt2 + colorSpeed) % 1.0;
    amt3 = (amt3 + colorSpeed) % 1.0;


    fill(flameColor(amt1));
    triangle(xPos + 6, yPos + 1, xPos + 46, yPos + 0, xPos + 25, yPos - 54);

    fill(flameColor(amt2));
    triangle(xPos + 6, yPos + 1, xPos + 46, yPos + 0, xPos + 25, yPos - 34);

    fill(flameColor(amt3));
    triangle(xPos + 6, yPos + 1, xPos + 46, yPos + 0, xPos + 25, yPos - 21);

    fill(109, 107, 105);
    square(xPos + 5, yPos + 0, 42);
  }
}

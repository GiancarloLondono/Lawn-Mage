class MainMenu 
{
  Button startButton, exitButton, instructionsButton;
  boolean isActive = true;
  boolean showInstructions = false;
  PImage menuBg;

  float flickerT  = 0.0;
  float flickerT2 = 0.0;

  MainMenu() 
  {
    menuBg = loadImage("Menu.jpg");

    startButton = new Button(300, 420, 200, 60, color(90, 40, 10));
    startButton.name        = "Start";
    startButton.textColor   = color(255, 220, 80);
    startButton.hoverColor  = color(160, 80, 20);
    startButton.normalColor = color(90, 40, 10);
    startButton.textSize    = 40;

    instructionsButton = new Button(300, 510, 200, 60, color(90, 40, 10));
    instructionsButton.name        = "How to Play";
    instructionsButton.textColor   = color(255, 220, 80);
    instructionsButton.hoverColor  = color(160, 80, 20);
    instructionsButton.normalColor = color(90, 40, 10);
    instructionsButton.textSize    = 28;

    exitButton = new Button(300, 600, 200, 60, color(90, 40, 10));
    exitButton.name        = "Exit";
    exitButton.textColor   = color(255, 220, 80);
    exitButton.hoverColor  = color(160, 80, 20);
    exitButton.normalColor = color(90, 40, 10);
    exitButton.textSize    = 40;
  }

  void HandleMenu() 
  {
    if (isActive) {
      Render();
      if (!showInstructions) {
        startButton.Hover();
        instructionsButton.Hover();
        exitButton.Hover();
      }
    }
  }

  void Render() 
  {
    image(menuBg, 0, 0, width, height);

    fill(0, 0, 0, 80); noStroke();
    rect(0, 0, width, height);

    // Torch flicker top-right
    flickerT  += 0.012;
    flickerT2 += 0.025;
    float n       = noise(flickerT);
    float sineA   = 0.5 + 0.5 * sin(flickerT  * 0.6);
    float sineB   = 0.5 + 0.5 * sin(flickerT2 * 1.3 + 0.9);
    float flicker = n * 0.55 + sineA * 0.30 + sineB * 0.15;
    if (random(1) < 0.004) flicker *= random(0.5, 0.75);
    int glowA = int(flicker * 110);
    noStroke();
    fill(255, 110, 10, int(glowA * 0.22)); ellipse(width, 0, 1100, 1100);
    fill(255, 140, 30, int(glowA * 0.40)); ellipse(width, 0, 620, 620);
    fill(255, 185, 60, int(glowA * 0.65)); ellipse(width, 0, 300, 300);
    fill(255, 220, 100, int(glowA * 0.90)); ellipse(width, 0, 130, 130);

    fill(0, 0, 0, 120); noStroke();
    rect(150, 260, 500, 110, 16);
    textAlign(CENTER, CENTER);
    textSize(90);
    fill(0, 0, 0, 180); text("Lawn Mage", 403, 318);
    fill(255, 220, 80);  text("Lawn Mage", 400, 315);

    DrawThemedButton(startButton);
    DrawThemedButton(instructionsButton);
    DrawThemedButton(exitButton);

    if (showInstructions) DrawInstructionsPopup();
  }

  void DrawThemedButton(Button b) 
  {
    fill(0, 0, 0, 100); noStroke();
    rect(b.xPos + 4, b.yPos + 4, b.Width, b.Height, 10);
    fill(b.buttonColor); stroke(200, 160, 50); strokeWeight(2);
    rect(b.xPos, b.yPos, b.Width, b.Height, 10);
    noStroke(); fill(b.textColor);
    textSize(b.textSize); textAlign(CENTER, CENTER);
    text(b.name, b.xPos + b.Width/2, b.yPos + b.Height/2);
  }

  void DrawInstructionsPopup() 
  {
    fill(0, 0, 0, 170); noStroke(); rect(0, 0, width, height);
    fill(0, 0, 0, 80); rect(84, 84, 632, 482, 16);
    stroke(200, 160, 50); strokeWeight(3); fill(60, 30, 5);
    rect(80, 80, 640, 480, 16);
    fill(210, 175, 110, 230); stroke(160, 120, 40); strokeWeight(1);
    rect(100, 100, 600, 440, 10);
    noStroke(); fill(80, 30, 5); textAlign(CENTER, CENTER);
    textSize(42); text("How to Play", 400, 150);
    stroke(120, 80, 20); strokeWeight(2); line(130, 175, 670, 175);
    noStroke(); fill(50, 20, 5); textSize(18); textAlign(LEFT, TOP);
    String msg = "Protect the wall from the green!\n\n" +
                 "W / S  -  Move Up / Down\n" +
                 "SPACEBAR  -  Shoot fireball\n\n" +
                 "Survive all 10 waves to win.\n" +
                 "Beat a level: wall gains +1 HP.\n" +
                 "A glowing +1 appears below\n" +
                 "the wall bar when you heal.\n\n" +
                 "Godspeed, you pointy-hatted bastard :)";
    text(msg, 130, 190, 540, 330);
    fill(90, 40, 10); stroke(200, 160, 50); strokeWeight(2);
    rect(300, 490, 200, 55, 10);
    noStroke(); fill(255, 220, 80); textSize(30);
    textAlign(CENTER, CENTER); text("Close", 400, 518);
  }

  void OnMouseReleased() 
  {
    if (isActive) {
      if (showInstructions) {
        if (mouseX > 300 && mouseX < 500 && mouseY > 490 && mouseY < 545)
          showInstructions = false;
        return;
      }
      if (startButton.isHovered) {
        if (startButton.Onclick()) {
          isActive = false;
          startButton.isHovered = false;
          game.isActive = true;
        }
      }
      if (instructionsButton.isHovered) {
        instructionsButton.Onclick(); showInstructions = true;
      }
      if (exitButton.isHovered) { exitButton.Onclick(); exit(); }
      if (!startButton.isHovered && !exitButton.isHovered && !instructionsButton.isHovered)
        player.AttackReset();
    }
  }
}

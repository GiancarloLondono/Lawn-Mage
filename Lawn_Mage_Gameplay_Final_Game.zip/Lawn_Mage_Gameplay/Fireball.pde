class Fireball 
{
  float xPos, yPos;
  float vx, vy;
  float speed = 18;
  boolean active;

  float currentAlpha, renderedAlpha, unrenderedAlpha;

  Fireball(float x, float y) 
  {
    xPos = x;
    yPos = y;

    renderedAlpha   = 255;
    unrenderedAlpha = 0;
    currentAlpha    = 0;
  }

  void Render() 
  {

    fill(10, 189, 255, currentAlpha);
    circle(xPos, yPos, 40);
    fill(240, 240, 240, currentAlpha);
    circle(xPos, yPos, 20);

    if (active) 
    {
      xPos += vx;
      yPos += vy;

      if (xPos > width + 50 || xPos < -50 || yPos > height + 50 || yPos < -50) 
      {
        Deactivate();
      }
    }
  }

  
  void Fire() 
  {
    if (!active) 
    {
      xPos = player.xPos;
      yPos = player.yPos;

      vx = speed;
      vy = 0;

      currentAlpha = renderedAlpha;
      active = true;
      PlayRandom(sfxFireball);
    }
  }

  void Deactivate() 
  {
    active       = false;
    currentAlpha = unrenderedAlpha;
    xPos         = player.xPos;
    yPos         = player.yPos;
  }

  void UpdateYPos() 
  {
    if (!active) 
    {
      xPos = player.xPos;
      yPos = player.yPos;
    }
  }

  void ActiveFollower() {}
}
